.. cmake-module:: ../../Modules/CheckStructHasMember.cmake
