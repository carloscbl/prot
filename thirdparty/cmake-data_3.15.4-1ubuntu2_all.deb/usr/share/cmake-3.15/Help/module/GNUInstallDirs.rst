.. cmake-module:: ../../Modules/GNUInstallDirs.cmake
