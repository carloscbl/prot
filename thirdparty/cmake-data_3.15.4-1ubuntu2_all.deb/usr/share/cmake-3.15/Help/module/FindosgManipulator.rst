.. cmake-module:: ../../Modules/FindosgManipulator.cmake
