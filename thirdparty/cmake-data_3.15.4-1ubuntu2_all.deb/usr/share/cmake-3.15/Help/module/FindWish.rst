.. cmake-module:: ../../Modules/FindWish.cmake
